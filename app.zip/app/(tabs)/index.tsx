import React, { useEffect, useMemo, useState } from "react";
import {
  Alert,
  Linking,
  Platform,
  SafeAreaView,
  Text,
  TouchableOpacity,
  View,
  ActivityIndicator,
  AppState,
} from "react-native";
import * as Location from "expo-location";
import sheltersData from "../../data/shelters.sc.json";
import { useRouter } from "expo-router";
import { Shelter, validateSheltersRuntime } from "../../src/utils/validateShelters";

const FALLBACK_DISTANCE = 999999;
const EMPTY_STATE_MESSAGE =
  "Support listings temporarily unavailable. Please use Resources & Hotlines.";

// ✅ Phase 2 GPS timeout handling
const GPS_TIMEOUT_MS = 9000; // 8–10s is a good Phase 2 window

type UiNotice =
  | { kind: "none" }
  | { kind: "info"; message: string }
  | { kind: "warning"; message: string };

function resolveNotice(params: {
  errorMsg?: string;
  locationDenied: boolean;
  servicesOff: boolean;
  sheltersCount: number;
  allDistancesFallback: boolean;
}): UiNotice {
  // Highest priority: explicit error message lane
  if (params.errorMsg) return { kind: "warning", message: params.errorMsg };

  if (params.servicesOff)
    return {
      kind: "warning",
      message: "Location Services are off. You can still use Resources & Hotlines.",
    };

  if (params.locationDenied)
    return {
      kind: "info",
      message:
        "Location access is off. You can still use Resources & Hotlines, or enable location to sort shelters by nearest.",
    };

  // Data integrity states (quiet + controlled)
  if (params.sheltersCount === 0 || params.allDistancesFallback)
    return { kind: "warning", message: EMPTY_STATE_MESSAGE };

  return { kind: "none" };
}

// ✅ Promise timeout helper
function withTimeout<T>(promise: Promise<T>, ms: number) {
  return Promise.race<T>([
    promise,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error("TIMEOUT")), ms)),
  ]);
}

export default function HomeScreen() {
  const router = useRouter();

  const shelters: Shelter[] = useMemo(() => {
    const flattened = (sheltersData as any)?.flat?.() ?? [];
    return validateSheltersRuntime(flattened);
  }, []);

  const [status, setStatus] = useState<
    "idle" | "requesting" | "granted" | "denied" | "error"
  >("idle");
  const [coords, setCoords] = useState<{ latitude: number; longitude: number } | null>(
    null
  );
  const [errorMsg, setErrorMsg] = useState<string>("");

  const [selectedShelter, setSelectedShelter] = useState<
    (Shelter & { distanceMiles: number }) | null
  >(null);

  const [privacyCover, setPrivacyCover] = useState(false);

  // v0.4 unified state flags
  const [servicesOff, setServicesOff] = useState(false);

  useEffect(() => {
    const sub = AppState.addEventListener("change", (state) => {
      if (state === "inactive" || state === "background") setPrivacyCover(true);
      if (state === "active") setTimeout(() => setPrivacyCover(false), 150);
    });

    return () => sub.remove();
  }, []);

  const toRad = (v: number) => (v * Math.PI) / 180;

  const distanceMiles = (
    a: { latitude: number; longitude: number } | null,
    b: { latitude: number; longitude: number } | null
  ) => {
    if (!a || !b) return FALLBACK_DISTANCE;
    if (![a.latitude, a.longitude, b.latitude, b.longitude].every(Number.isFinite))
      return FALLBACK_DISTANCE;

    const R = 3958.8;
    const dLat = toRad(b.latitude - a.latitude);
    const dLon = toRad(b.longitude - a.longitude);

    const lat1 = toRad(a.latitude);
    const lat2 = toRad(b.latitude);

    const h =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;

    const miles = 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
    return Number.isFinite(miles) ? miles : FALLBACK_DISTANCE;
  };

  const isValidDistance = (d: number) =>
    Number.isFinite(d) && d >= 0 && d < FALLBACK_DISTANCE;

  const allDistancesFallback = useMemo(() => {
    if (!coords) return false;
    if (shelters.length === 0) return true;

    // If every shelter computes to fallback, we treat it as controlled empty state.
    return shelters.every((s) => {
      const d = distanceMiles(coords, { latitude: s.latitude, longitude: s.longitude });
      return !isValidDistance(d);
    });
  }, [coords, shelters]);

  const findClosestShelter = (user: { latitude: number; longitude: number }, list: Shelter[]) => {
    let closest: (Shelter & { distanceMiles: number }) | null = null;

    for (const s of list) {
      const d = distanceMiles(user, { latitude: s.latitude, longitude: s.longitude });
      if (!isValidDistance(d)) continue; // v0.4 deterministic guard: ignore fallback distances
      if (!closest || d < closest.distanceMiles) {
        closest = { ...s, distanceMiles: d };
      }
    }
    return closest;
  };

  const requestLocation = async () => {
    try {
      setStatus("requesting");
      setErrorMsg("");
      setServicesOff(false);

      // v0.4: if shelters are invalid/empty, we still do not crash —
      // but we can short-circuit to controlled empty state after permission checks.
      const existing = await Location.getForegroundPermissionsAsync();
      let permStatus = existing.status;

      if (permStatus !== "granted") {
        const req = await Location.requestForegroundPermissionsAsync();
        permStatus = req.status;
      }

      if (permStatus !== "granted") {
        setStatus("denied");
        return;
      }

      const servicesEnabled = await Location.hasServicesEnabledAsync();
      if (!servicesEnabled) {
        setServicesOff(true);
        setStatus("error");
        return;
      }

      // ✅ Phase 2: try fresh GPS with a timeout, then fallback to last known
      let lat: number | null = null;
      let lon: number | null = null;

      try {
        const current = await withTimeout(
          Location.getCurrentPositionAsync({
            // Balanced is faster; High can hang more often.
            accuracy: Location.Accuracy.Balanced,
          }),
          GPS_TIMEOUT_MS
        );

        lat = Number(current.coords.latitude);
        lon = Number(current.coords.longitude);
      } catch (e: any) {
        const last = await Location.getLastKnownPositionAsync();

        if (last?.coords) {
          lat = Number(last.coords.latitude);
          lon = Number(last.coords.longitude);

          if (__DEV__) {
            console.warn("[Location] Using last known position fallback.");
          }
        } else {
          setStatus("error");
          setErrorMsg(
            e?.message === "TIMEOUT"
              ? "Location is taking too long. Try moving near a window or turning on GPS, then retry."
              : "Unable to get your location right now. Please try again."
          );
          return;
        }
      }

      if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
        setStatus("error");
        setErrorMsg("Invalid location data received.");
        return;
      }

      const userCoords = { latitude: lat, longitude: lon };
      setCoords(userCoords);

      // v0.4: controlled empty state if shelters are empty OR all distances fallback
      if (shelters.length === 0) {
        setStatus("error");
        // leave errorMsg empty → unified notice will show controlled message
        return;
      }

      const closest = findClosestShelter(userCoords, shelters);

      if (!closest) {
        // This covers: all distances fallback, or data unusable even after validation.
        setStatus("error");
        // no errorMsg → unified notice handles controlled empty state
        return;
      }

      setSelectedShelter(closest);
      setStatus("granted");
    } catch (e: any) {
      setStatus("error");
      setErrorMsg(e?.message ?? "Error accessing location.");
    }
  };

  const resetHome = () => {
    setStatus("idle");
    setCoords(null);
    setErrorMsg("");
    setServicesOff(false);
    setSelectedShelter(null);
  };

  const openMapsToDestination = async (destination: { latitude: number; longitude: number }) => {
    const { latitude, longitude } = destination;

    // v0.4: hard guard — do not attempt maps if coords are invalid
    if (![latitude, longitude].every(Number.isFinite)) {
      Alert.alert("Error", "Destination coordinates unavailable.");
      return;
    }

    const url =
      Platform.OS === "ios"
        ? `http://maps.apple.com/?daddr=${latitude},${longitude}`
        : `https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}`;

    const canOpen = await Linking.canOpenURL(url);
    if (canOpen) {
      await Linking.openURL(url);
    } else {
      Alert.alert("Error", "Could not open Maps app.");
    }
  };

  // Opens a neutral, high-traffic site to safely exit the app
  const quickExit = async () => {
    setPrivacyCover(true);
    resetHome();

    const safeUrl = "https://www.weather.com";
    setTimeout(async () => {
      try {
        await Linking.openURL(safeUrl);
      } catch {}
    }, 120);
  };

  const offlineFallback = () => {
    Alert.alert(
      "Direct Support",
      "National Domestic Violence Hotline:\n\n📞 1-800-799-7233\n📱 Text START to 88788",
      [{ text: "OK" }]
    );
  };

  const notice: UiNotice = resolveNotice({
    errorMsg: status === "error" ? errorMsg : undefined,
    locationDenied: status === "denied",
    servicesOff,
    sheltersCount: shelters.length,
    allDistancesFallback: Boolean(coords) && allDistancesFallback,
  });

  const showShelterCard =
    status === "granted" &&
    selectedShelter &&
    isValidDistance(selectedShelter.distanceMiles);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#fff" }}>
      <View style={{ padding: 16 }}>
        <View style={{ flexDirection: "row", justifyContent: "flex-end" }}>
          <TouchableOpacity
            onPress={quickExit}
            accessibilityLabel="Quick Exit"
            style={{
              padding: 6,
              paddingHorizontal: 14,
              borderRadius: 999,
              borderWidth: 1.5,
              borderColor: "#C62828",
            }}
          >
            <Text style={{ fontWeight: "600", color: "#C62828" }}>Quick Exit</Text>
          </TouchableOpacity>
        </View>

        <View style={{ marginTop: 40, gap: 12 }}>
          <Text style={{ fontSize: 28, fontWeight: "700" }}>You’re not alone.</Text>
          <Text style={{ fontSize: 16 }}>We can help you find nearby support fast.</Text>

          {status === "requesting" ? (
            <View style={{ padding: 40, alignItems: "center" }}>
              <ActivityIndicator size="large" color="#000" />
              <Text style={{ marginTop: 10 }}>Finding nearest shelter...</Text>
            </View>
          ) : (
            <TouchableOpacity
              onPress={requestLocation}
              style={{
                padding: 20,
                borderRadius: 16,
                backgroundColor: "#000",
                alignItems: "center",
              }}
            >
              <Text style={{ fontSize: 18, fontWeight: "700", color: "#fff" }}>Find Help</Text>
              <Text style={{ marginTop: 6, color: "#ccc", textAlign: "center" }}>
                We use your location only to find nearby help.
              </Text>
            </TouchableOpacity>
          )}

          {/* v0.4 Unified Notice Surface (single lane) */}
          {notice.kind !== "none" && (
            <View
              style={{
                marginTop: 12,
                padding: 12,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: notice.kind === "warning" ? "#f0c2c2" : "#d8e7ff",
                backgroundColor: "#fff",
              }}
            >
              <Text
                style={{
                  fontWeight: "700",
                  textAlign: "center",
                  color: notice.kind === "warning" ? "crimson" : "#0b3d91",
                }}
              >
                {notice.kind === "warning" ? "Notice" : "Info"}
              </Text>

              <Text style={{ marginTop: 6, color: "#444", textAlign: "center" }}>
                {notice.message}
              </Text>

              {status === "denied" && (
                <TouchableOpacity
                  onPress={() => Linking.openSettings()}
                  style={{
                    marginTop: 10,
                    padding: 12,
                    borderRadius: 10,
                    backgroundColor: "#eee",
                    alignItems: "center",
                  }}
                >
                  <Text style={{ fontWeight: "600" }}>Open Settings</Text>
                </TouchableOpacity>
              )}

              {/* ✅ Phase 2: Retry button for timeout/unavailable/errors */}
              {status === "error" && (
                <TouchableOpacity
                  onPress={requestLocation}
                  style={{
                    marginTop: 10,
                    padding: 12,
                    borderRadius: 10,
                    backgroundColor: "#eee",
                    alignItems: "center",
                  }}
                >
                  <Text style={{ fontWeight: "600" }}>Retry</Text>
                </TouchableOpacity>
              )}
            </View>
          )}

          {/* v0.4 Shelter Card only when distance is real (not fallback) */}
          {showShelterCard && (
            <View style={{ borderWidth: 1, borderRadius: 12, padding: 16, marginTop: 10 }}>
              <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                <Text style={{ fontSize: 18, fontWeight: "700" }}>Shelter Found</Text>
                <TouchableOpacity onPress={resetHome}>
                  <Text style={{ fontWeight: "600" }}>Start Over</Text>
                </TouchableOpacity>
              </View>

              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-between",
                  marginTop: 8,
                }}
              >
                <Text style={{ fontSize: 16, fontWeight: "600", flex: 1, paddingRight: 10 }}>
                  {selectedShelter.name}
                </Text>

                {selectedShelter.verified && (
                  <View
                    style={{
                      paddingVertical: 4,
                      paddingHorizontal: 10,
                      borderRadius: 999,
                      borderWidth: 1,
                      borderColor: "#1D9BF0",
                      backgroundColor: "#E8F3FF",
                    }}
                  >
                    <Text style={{ fontSize: 12, fontWeight: "700", color: "#1D9BF0" }}>
                      Verified
                    </Text>
                  </View>
                )}
              </View>

              <Text style={{ color: "#666" }}>
                {selectedShelter.distanceMiles.toFixed(1)} miles away
              </Text>

              <View style={{ flexDirection: "row", gap: 10, marginTop: 12 }}>
                <TouchableOpacity
                  onPress={() => openMapsToDestination(selectedShelter)}
                  style={{
                    flex: 1,
                    padding: 12,
                    borderRadius: 10,
                    backgroundColor: "#eee",
                    alignItems: "center",
                  }}
                >
                  <Text style={{ fontWeight: "600" }}>Start Directions</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => {
                    router.push({
                      pathname: "/shelters",
                      params: {
                        lat: coords?.latitude?.toString() ?? "",
                        lon: coords?.longitude?.toString() ?? "",
                      },
                    });
                  }}
                  style={{
                    flex: 1,
                    padding: 12,
                    borderRadius: 10,
                    borderWidth: 1,
                    borderColor: "#ddd",
                    alignItems: "center",
                  }}
                >
                  <Text style={{ fontWeight: "600" }}>Other Shelters</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          <TouchableOpacity
            onPress={offlineFallback}
            style={{
              padding: 14,
              borderRadius: 12,
              borderWidth: 1,
              borderColor: "#ccc",
              alignItems: "center",
              marginTop: 10,
            }}
          >
            <Text style={{ fontSize: 16, fontWeight: "500" }}>Resources & Hotlines</Text>
          </TouchableOpacity>
        </View>
      </View>

      {privacyCover && (
        <View
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: "#fff",
            alignItems: "center",
            justifyContent: "center",
            padding: 24,
            zIndex: 9999,
            elevation: 9999,
          }}
        >
          <Text style={{ fontSize: 18, fontWeight: "700" }}>One moment…</Text>
        </View>
      )}
    </SafeAreaView>
  );
}
